package com.projeto.ProjetoPessoal1;

import lombok.Data;

@Data
public class Pessoa {
    private int id;
    private String nome;
    private String endereco;
    private String telefone;
    private String cidade;
}
