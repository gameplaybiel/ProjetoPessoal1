package com.projeto.ProjetoPessoal1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoPessoal1Application {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoPessoal1Application.class, args);
	}

}
